class LatihanFor{
    public static void main(String args[]){
        for( byte i=1;i<=10;++i)
        System.out.println("Anak ayam "+ i +" turun ");
    }
}