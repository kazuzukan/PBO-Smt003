public class UjiSelamat {
	public static void main (String[] args) {
		Selamat hello = new Selamat();
		hello.greet();
 	}
}
