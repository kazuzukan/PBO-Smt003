public class Dimensi2{
    public double sisi1,sisi2,sisi3;
}