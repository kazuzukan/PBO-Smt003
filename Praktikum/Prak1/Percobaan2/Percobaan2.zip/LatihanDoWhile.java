class LatihanDoWhile{
    public static void main(String args[]){
    byte i=1;
        do {
        System.out.println("Anak ayam "+ i +" turun ");i++;
        } while(i<=3);
    }
}