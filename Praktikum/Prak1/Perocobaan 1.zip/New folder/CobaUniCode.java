public class CobaUniCode{
	public static void main(String[] args) {
		ch\u0061r a='a';
		char \u0062 = 'b'; char c= '\u0063';
		String kata="\u0061\u0062\u0063";
		System.out.println("a: " + a);
		System.out.println("a: " + b);
		System.out.println("a: " + c);
		System.out.println("kata: " + kata);
	}
}