public class Plus{
	public static void main(String[] args) {
		int x;
		int y;
		x = 2147483647; //(2^31)-1
		System.out.println("x = "+x);
		y=x+1;
		System.out.println("y = "+y);
	}
}