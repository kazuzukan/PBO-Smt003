public class Selamat{
	public void greet() {
		System.out.println("Hi");
	}
}
