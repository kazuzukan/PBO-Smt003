    public class DemoTugas1{
        public static void main(String [] args) {
            MenuTugas1 menu = new MenuTugas1();
        }
    }