public class Dimensi2{
    public static double sisi1,sisi2,sisi3;
}